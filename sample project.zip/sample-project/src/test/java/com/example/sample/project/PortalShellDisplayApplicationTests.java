package com.example.sample.project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PortalShellDisplayApplicationTests {

	@Test
	void contextLoads() {
	}

}
