package com.example.sample.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PortalShellDisplayApplication {

	public static void main(String[] args) {
		SpringApplication.run(PortalShellDisplayApplication.class, args);
	}

}
